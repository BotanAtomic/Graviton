/*
Navicat MySQL Data Transfer

Source Server         : Graviton
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : login

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2016-04-10 18:29:25
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `accounts`
-- ----------------------------
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `pseudo` text,
  `question` varchar(255) NOT NULL DEFAULT 'Supprimer ?',
  `answer` varchar(255) NOT NULL DEFAULT 'oui',
  `gift` varchar(255) DEFAULT NULL,
  `informations` text,
  `friends` text,
  `enemies` text,
  `bank` varchar(255) DEFAULT NULL,
  `mute` longtext,
  `ban` longtext,
  `rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`account`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of accounts
-- ----------------------------
INSERT INTO `accounts` VALUES ('1', 'bobo', 'bobo', 'salutation', 'Supprimer ?', 'oui', null, '2016~04~10~18~20~127.0.0.1', '', '', '0;', '', null, '4');

-- ----------------------------
-- Table structure for `ban`
-- ----------------------------
DROP TABLE IF EXISTS `ban`;
CREATE TABLE `ban` (
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of ban
-- ----------------------------
INSERT INTO `ban` VALUES ('');

-- ----------------------------
-- Table structure for `players`
-- ----------------------------
DROP TABLE IF EXISTS `players`;
CREATE TABLE `players` (
  `id` int(11) NOT NULL,
  `account` int(11) DEFAULT NULL,
  `name` varchar(11) NOT NULL,
  `class` int(11) NOT NULL,
  `size` int(11) DEFAULT '100',
  `sex` int(11) DEFAULT NULL,
  `gfx` int(11) DEFAULT NULL,
  `colors` text,
  `spells` text,
  `spellpoints` int(11) DEFAULT NULL,
  `capital` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `experience` bigint(11) DEFAULT NULL,
  `items` text,
  `kamas` bigint(20) DEFAULT '1000000',
  `statistics` varchar(40) NOT NULL DEFAULT '0;0;0;0;0;0',
  `alignement` varchar(110) NOT NULL DEFAULT '0;0;0;0',
  `jobs` text,
  `title` int(11) DEFAULT '0',
  `position` varchar(11) NOT NULL DEFAULT '0;0',
  `server` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`name`,`server`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of players
-- ----------------------------

-- ----------------------------
-- Table structure for `servers`
-- ----------------------------
DROP TABLE IF EXISTS `servers`;
CREATE TABLE `servers` (
  `id` int(11) NOT NULL DEFAULT '0',
  `key` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of servers
-- ----------------------------
INSERT INTO `servers` VALUES ('1', 'pvp');
INSERT INTO `servers` VALUES ('2', 'pvm');
INSERT INTO `servers` VALUES ('3', 'pvp1');
INSERT INTO `servers` VALUES ('4', 'pvp2');
INSERT INTO `servers` VALUES ('5', 'vip');
